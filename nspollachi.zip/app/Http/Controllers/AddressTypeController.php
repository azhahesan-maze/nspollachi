<?php

namespace App\Http\Controllers;

use App\Models\AddressType;
use Illuminate\Http\Request;

class AddressTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.master.state.add');
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $address_type=array("Permanent Address","Temporary Address","Shipping Address","Delivery Address");
        $data=array();
        foreach($address_type as $value){
            $data_array=array(
                'name'=>$value,
                'created_by' => 0,
                'updated_by' => 0,

            );
            $data[]=$data_array;

        }

        AddressType::insert($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AddressType  $addressType
     * @return \Illuminate\Http\Response
     */
    public function show(AddressType $addressType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AddressType  $addressType
     * @return \Illuminate\Http\Response
     */
    public function edit(AddressType $addressType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AddressType  $addressType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AddressType $addressType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\AddressType  $addressType
     * @return \Illuminate\Http\Response
     */
    public function destroy(AddressType $addressType)
    {
        //
    }
}
