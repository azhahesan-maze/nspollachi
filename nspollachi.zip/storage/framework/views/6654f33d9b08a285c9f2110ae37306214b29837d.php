<?php $__env->startSection('content'); ?>
<div class="col-12 body-sec">
      <div class="card container px-0">
        <!-- card header start@ -->
        <div class="card-header px-2">
          <div class="row">
            <div class="col-4">
              <h3 >Add Branch</h3>
            </div>
            <div class="col-8 mr-auto">
              <ul class="h-right-btn mb-0 pl-0">
                <li><button type="button" class="btn btn-success"><a href="index.php">Back</a></button></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- card header end@ -->
        <div class="card-body">
        <form class="needs-validation" novalidate>

          <div class="form-row">
            <div class="col-md-6">
              <div class="form-group row">
              <label for="validationCustom01" class="col-sm-4 col-form-label">First name<span class="mandatory">*</span></label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="validationCustom01" placeholder="First name" required>
                <div class="invalid-feedback">
              Enter valid First Name
              </div>
              </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group row">
              <label for="validationCustom01" class="col-sm-4 col-form-label">Last name</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="validationCustom01" placeholder="First name" required>
                <div class="invalid-feedback">
              Enter valid Last Name
              </div>
              </div>
              </div>
            </div>
          </div>

          <div class="form-row">
            <div class="col-md-6">
              <div class="form-group row">
              <label for="validationCustom01" class="col-sm-4 col-form-label">Phone Number</label>
              <div class="col-sm-8">
                <input type="tel" class="form-control" id="validationCustom01" placeholder="Phone Number" 
                pattern="^\d{4}\d{2}\d{4}$" required>
                <div class="invalid-feedback">
                  Enter valid Number
              </div>
              </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group row">
              <label for="validationCustom01" class="col-sm-4 col-form-label">Email</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="validationCustom01" placeholder="Email"
                pattern="[^@\s]+@[^@\s]+" required>
                <div class="invalid-feedback">
                Enter Valid Email 
              </div>
              </div>
              </div>
            </div>
          </div>

          <div class="form-group row mb-3">
          <label for="validationTextarea" class="col-md-2">Textarea</label>
          <textarea class="form-control col-md-10" id="validationTextarea" placeholder="Required example textarea" ></textarea>
          
          </div>

        <div class="row">
        <div class="col-md-6">
        <div class="form-group row">
          <div class="col-md-4">
            <label>Select option</label>
          </div>
          <div class="col-md-8">
          <select class="custom-select" required>
            <option value="">Open this select menu</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
          </div>
            <div class="invalid-feedback">select this fields</div>
          </div>
        </div>

        <div class="col-md-6">
        <div class="form-group row">
          <div class="col-md-4">
            <label>Select File</label>
          </div>
          <div class="col-md-8">
          <div class="custom-file">
            <input type="file" class="custom-file-input" id="validatedCustomFile" required>
            <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
            <div class="invalid-feedback">Choose file</div>
          </div>
          </div>

          </div>
        </div>
        </div>

        <div class="form-group row">
        <div class="col-md-6">
          <div class="custom-control custom-switch">
          <input type="checkbox" class="custom-control-input" id="customSwitch1" required> 
          <label class="custom-control-label" for="customSwitch1">Toggle this switch element</label>
          <div class="invalid-feedback">
            Please Check this
          </div>
          </div>
        </div>
        <div class="col-md-6">
          <label for="customRange1">Range Slider</label>
          <input type="range" class="custom-range" id="customRange1">
        </div>
      </div>

          <div class="custom-control custom-checkbox mb-3">
          <input type="checkbox" class="custom-control-input" id="customControlValidation1" required>
          <label class="custom-control-label" for="customControlValidation1">Check this checkbox</label>
          <div class="invalid-feedback">Check this feedfack</div>
        </div>

        <!-- select 2 -->
        <h3 class="col-12">Select 2 </h3>
        <div class="col-12 py-3">
          <select class="js-example-basic-multiple col-12 custom-select" name="states[]" multiple="multiple" required>
            <option value="AL">Alabama</option>
            <option value="WY">Wyoming</option>
            <option value="my">Manoj</option>
            <option value="mh">Mohan</option>
            <option value="mn">Mani</option>
          </select>
          <div class="invalid-feedback">select this fields</div>
        </div>

        <div class="col-12">
            <input id="datepicker" />
        </div>

  <button class="btn btn-success" type="submit">Submit</button>

      
</form>
        </div>
        <!-- card body end@ -->
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\nspollachi\resources\views/Masters/Sample/Add.blade.php ENDPATH**/ ?>