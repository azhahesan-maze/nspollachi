
    
  <?php include'header.php'; ?>

  <!-- body section -->
  
    <div class="col-12 body-sec px-0">
      <div class="card">
        <!-- card header start@ -->
        <div class="card-header px-2">
          <div class="row mx-0">
            <div class="col-4">
              <h3>Sales</h3>
            </div>
          </div>
        </div>
        <!-- card header end@ -->
        <div class="card-body p-0">
            <div class="row mx-0">
              <div class="col-9 px-0">
                <div class="row mx-0">
                  <div class="col-5 px-0">
                    <table class="sales1">
                      <tr>
                        <td>Code*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Code*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Code*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Code*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Code*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Code*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Code*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Code*</td>
                        <td></td>
                      </tr>
                    </table>
                  </div>
                  <div class="col-7 px-0">
                  <table class="sales1" id="t-sales1">
                      <tr>
                        <td>Salesman*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Holdbils*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Door delivery</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>print</td>
                        <td></td>
                      </tr>
                     
                    </table>
                  </div>
                </div>
                  <div class="col-12 px-0">
                  <table class="sales2">
                      <thead>
                        <tr>
                          <th>Sno</th>
                          <th>Code</th>
                          <th>Descrption</th>
                          <th>Qty</th>
                          <th>Rate</th>
                          <th>Amount</th>
                          <th>M.R.P</th>
                          <th>Tax %</th>
                          <th>Qty</th>
                          <th>Rate</th>
                          <th>Amount</th>
                          <th>M.R.P</th>
                          <th>Tax %</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>2</td>
                          <td>AASHIRAVAD SELECT ATTA 5KG</td>
                          <td>1</td>
                          <td>235.00</td>
                          <td>235.00</td>
                          <td>246.75</td>
                          <td>0%</td>
                        </tr>
                      </tbody>
                     
                    </table>
                  </div>
              </div>
              <div class="col-3 px-0">
              <table class="sales1 t-sales1" id="t-sales1">
                      <tr>
                        <td>Salesman*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Holdbils*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Door delivery</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>print</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Salesman*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Holdbils*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Door delivery</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>print</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Holdbils*</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Door delivery</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>print</td>
                        <td></td>
                      </tr>
                     
                    </table>
              </div>
            </div>
                
        </div>
        <!-- card body end@ -->
      </div>
    </div>

    <div class="col-12 px-0" id="price">
        <table>
          <tbody>
            <tr>
              <td>R-50 <br/> Ctrl-1</td>
              <td>R-50 <br/> Ctrl-1</td>
              <td>R-50 <br/> Ctrl-1</td>
              <td>R-50 <br/> Ctrl-1</td>
              <td>R-50 <br/> Ctrl-1</td>
              <td>R-50 <br/> Ctrl-1</td>
              <td class="pb-2"><span class="px-5">Net Amount</span> 5070.00</td>
            </tr>
          </tbody>
        </table>
    </div>
    
  

  
  

  <?php include'footer.php'; ?>
    
  