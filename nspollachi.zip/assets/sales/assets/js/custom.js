$(document).ready(function() {
    $('#master').DataTable();
} );