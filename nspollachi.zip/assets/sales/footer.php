<section class="foot">

      <div class="col-12 px-0">
      <div class="row mx-0">
        <div class="col-6">
          <p>© 2019 Copyright.</p>
        </div>
        <div class="col-6 text-right">
           <p>Mazenetsolution</p> 
        </div>
      </div>
    
</div>
</section>
    
</div>
    <!-- main js -->
    <script src="assets/js/jquery.js" ></script>
    <!-- Optional JavaScript -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/dataTables.bootstrap4.min.js"></script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/js/popper.min.js" ></script>
    <script src="assets/js/bootstrap.min.js" ></script>
    </body>
</html>